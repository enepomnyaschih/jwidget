# Download

[Download jWidget](guides/endownload/jwidget.zip)

[Source code and bug tracker on GitHub](https://github.com/enepomnyaschih/jwidget)

jWidget is available as [Bower](http://bower.io/) package:

    bower install jwidget
